document.getElementById("darkModeToggle").addEventListener("click", function() {
    document.body.classList.toggle("dark-mode");
});

document.getElementById("loginButton").addEventListener("click", function() {
    this.innerHTML = "Logging in...";
    setTimeout(() => {
        this.innerHTML = "Login Securely";
    }, 2000);
});

document.getElementById("closeBanner").addEventListener("click", function() {
    document.querySelector(".security-banner").style.display = "none";
});